angular
  .module('app')
  .controller('Chart1Ctrl', Chart1Ctrl)

function onLoad(div_id) {

  var data = [
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Capsule+SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Capsule-FinalSBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Offshore",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Learning-BatchNtStarted",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Capsule+SBA",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Capsule-FinalSBA",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Offshore",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Capsule+SBA",
      "count": 13
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Capsule-FinalSBA",
      "count": 3
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Offshore",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Capsule+SBA",
      "count": 10
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Capsule-FinalSBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Agero, Inc",
      "location": "Onsite",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Learning-BatchNtStarted",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Capsule+SBA",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Capsule-FinalSBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "AIG",
      "location": "Onsite",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "PreAssessment (KBA) Pending",
      "count": 10
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Capsule+SBA",
      "count": 6
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Capsule-FinalSBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV01-Jagan",
      "account": "Prudential Insurance",
      "location": "Onsite",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "PreAssessment (KBA) Pending",
      "count": 2
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Learning",
      "count": 13
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Capsule+SBA",
      "count": 12
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Capsule-FinalSBA",
      "count": 2
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "NORTHWESTERN MUTUAL",
      "location": " Offshore",
      "status": "Certified",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Nominated",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "PreAssessment (KBA) Pending",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Learning-BatchNtStarted",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Learning",
      "count": 1
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Capsule+SBA",
      "count": 3
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Capsule-FinalSBA",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Final SBA",
      "count": 0
    },
    {
      "sbu": "SV03-Kiran",
      "account": "Farmers Insurance",
      "location": " Onsite",
      "status": "Certified",
      "count": 0
    }
  ];

  // This is the simple vertical grouped stacked 100% bar example
  var svg = dimple.newSvg(div_id,900, 500);

  var svgElement;

  const diffcolors = [new dimple.color("#e41a1c"),
  new dimple.color("#377eb8"),
  new dimple.color("#4daf4a"),
  new dimple.color("#984ea3"),
  new dimple.color("#ff7f00"),
  new dimple.color("#ffff33"),
  new dimple.color("#a65628"),
  new dimple.color("#f781bf")]

  //d3.json(csvfile, function (error,data) {}

  /*filtering logic for demo only*/
  //var filteredData= dimple.filterData(data,"status",["Learning-BatchNtStarted","Capsule+SBA"]);

  var myChart = new dimple.chart(svg, data);
  //'#ffffff','#ffdc7d','#f7b44c','#e19030','#c66f1f','#a65116','#833811','#5d240e','#341508','#000000'
  /*  myChart.defaultColors = [new dimple.color("#ffffff"),new dimple.color("#ffdc7d"),new dimple.color("#f7b44c"),new dimple.color("#e19030"),new dimple.color("#c66f1f"),new dimple.color("#a65116"),new dimple.color("#833811"),new dimple.color("#5d240e"),new dimple.color("#341508"),new dimple.color("#000000")];*/

  myChart.defaultColors = diffcolors;
  myChart.setBounds(65, 45, 505, 315)
  //sbu,account,location,status,count
  var x = myChart.addCategoryAxis("x", ["sbu", "location"], "asc");
  var y = myChart.addMeasureAxis("y", "count");
  var s = myChart.addSeries("status", dimple.plot.bar);
  //s.addOrderRule(["Nominated", "PreAssessment (KBA) Pending"])
  s.addOrderRule(["Nominated", "PreAssessment (KBA) Pending", "Learning-BatchNtStarted", "Learning", "Capsule+SBA", "Capsule-FinalSBA", "Final SBA", "Certified"]);
  // Using the afterDraw callback means this code still works with animated
  // draws (e.g. myChart.draw(1000)) or storyboards (though an onTick callback should
  // also be used to clear the text from the previous frame)
  s.afterDraw = function (shape, data) {


    // Get the shape as a d3 selection
    var s = d3.select(shape),
      rect = {
        x: parseFloat(s.attr("x")),
        y: parseFloat(s.attr("y")),
        width: parseFloat(s.attr("width")),
        height: parseFloat(s.attr("height"))
      };
    // Only label bars where the text can fit
    if (rect.height >= 8) {
      // Add a text label for the value
      svgElement = svg.append("text")
        // Position in the centre of the shape (vertical position is
        // manually set due to cross-browser problems with baseline)
        .attr("x", rect.x + rect.width / 2)
        .attr("y", rect.y + rect.height / 2 + 3.5)
        // Centre align
        .style("text-anchor", "middle")
        .style("font-size", "13px")
        .style("font-family", "sans-serif")
        // Make it a little transparent to tone down the black
        .style("opacity", 0.6)
        // Prevent text cursor on hover and allow tooltips
        .style("pointer-events", "none")
        // Format the number
        //.text((data.yValue));
    }
  };
  var legend=myChart.addLegend(500, 10, 280, 300, "right");

  myChart.draw();

  legend.shapes.selectAll("text").style("font-size", "12px");

  //On change of SBU
  d3.select("#sbu").on("change", function () {

    var selectedValue = this.options[this.selectedIndex].value;

    if (selectedValue === "All") {
      selectedValue = ["SV01-Jagan", "SV03-Kiran"];
    }
    var filteredData = dimple.filterData(data, "sbu", selectedValue);

    myChart.data = filteredData;
    myChart.draw();

  });

  //On change of Location
  d3.select("#location").on("change", function () {

    var selectedValue = this.options[this.selectedIndex].value;
    if (selectedValue === "All") {
      selectedValue = ["Offshore", "Onsite"];
    }
    var filteredData = dimple.filterData(data, "location", selectedValue);

    myChart.data = filteredData;

    myChart.draw();

  });

  //On change of Status
  d3.select("#status").on("change", function () {

    var selectedValue = this.options[this.selectedIndex].value;
    var filteredData = dimple.filterData(data, "status", selectedValue);

    myChart.data = filteredData;
    myChart.draw();

  });


}

Chart1Ctrl.$inject = ['$scope'];
function Chart1Ctrl($scope) {
  console.log("Inside controller");
  onLoad("#chartContainer1");
}


