package com.cts.trt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "SBU_Details")
public class SBUDetails implements Serializable {
 
	@Id
	private long sbuId;
	
	@Column(name = "sbu_name")
	private String sbuName;

	public long getSbuId() {
		return sbuId;
	}

	public void setSbuId(long sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

}
