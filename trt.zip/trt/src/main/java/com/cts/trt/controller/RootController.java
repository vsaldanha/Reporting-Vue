package com.cts.trt.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.cts.trt.model.Associate;
import com.cts.trt.model.Response;

@RestController
public class RootController {

	/*@Autowired
	SbuInfo repository;
	
	@RequestMapping("/findall")
	public Response findAll(){
		Iterable<Associate> sbus = repository.findAll();
		 
		return new Response("Done", sbus);
	}*/
	
		
	/*@RequestMapping("/findbyid")
	public String findById(@RequestParam("id") long id){
		String result = "";
		result = repository.findOne(id).toString();
		return result;
	}*/

}
