package com.cts.trt.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Associate_Training")
public class AssociateTraining implements Serializable {

	private static final long serialVersionUID = -3009157732242241606L;
	@Id
	private long associateId;
	
	@ManyToOne
	@JoinColumn(name = "training_id")
	private TrainingDetails training;

	@Column(name = "department_group")
	private String departmentGroup;

	@Column(name = "learning_recommemdation")
	private String learningRecommemdation;

	@Column(name = "reporting_status")
	private String reportingStatus;

	@Column(name = "assessment_administered")
	private Date assessmentAdministered;
	
	@Column(name = "learning_program_start")
	private Date learningProgStart;

	@Column(name = "ageing_since_prog_start")
	private long ageingSinceProgStart;
	
	@Column(name = "ageing_gp_since")
	private long ageingGpSince;

	@Column(name = "attendance")
	private long attendance;
	
	@Column(name = "assessment_completion")
	private Date assessmentCompletion;

	@Column(name = "committed_sba_completion_date")
	private Date committedSbaCompletionDate;
	
	@Column(name = "deployment_plan_update")
	private String deploymentPlanUpdate;

	@Column(name = "deployment_confirmation_poc_id")
	private long deploymentConfirmationPocId;

	@Column(name = "deployment_confirmation_poc_name")
	private String deploymentConfirmationPocName;

	@Column(name = "drop_reason")
	private String dropReason;
	
	@Column(name = "academy_poc")
	private String academyPoc;

	@Column(name = "sba_administration_date")
	private Date sbaAdministrationDate;

	public long getAssociateId() {
		return associateId;
	}

	public void setAssociateId(long associateId) {
		this.associateId = associateId;
	}

	public TrainingDetails getTraining() {
		return training;
	}

	public void setTraining(TrainingDetails training) {
		this.training = training;
	}

	public String getDepartmentGroup() {
		return departmentGroup;
	}

	public void setDepartmentGroup(String departmentGroup) {
		this.departmentGroup = departmentGroup;
	}

	public String getLearningRecommemdation() {
		return learningRecommemdation;
	}

	public void setLearningRecommemdation(String learningRecommemdation) {
		this.learningRecommemdation = learningRecommemdation;
	}

	public String getReportingStatus() {
		return reportingStatus;
	}

	public void setReportingStatus(String reportingStatus) {
		this.reportingStatus = reportingStatus;
	}

	public Date getAssessmentAdministered() {
		return assessmentAdministered;
	}

	public void setAssessmentAdministered(Date assessmentAdministered) {
		this.assessmentAdministered = assessmentAdministered;
	}

	public Date getLearningProgStart() {
		return learningProgStart;
	}

	public void setLearningProgStart(Date learningProgStart) {
		this.learningProgStart = learningProgStart;
	}

	public long getAgeingSinceProgStart() {
		return ageingSinceProgStart;
	}

	public void setAgeingSinceProgStart(long ageingSinceProgStart) {
		this.ageingSinceProgStart = ageingSinceProgStart;
	}

	public long getAgeingGpSince() {
		return ageingGpSince;
	}

	public void setAgeingGpSince(long ageingGpSince) {
		this.ageingGpSince = ageingGpSince;
	}

	public long getAttendance() {
		return attendance;
	}

	public void setAttendance(long attendance) {
		this.attendance = attendance;
	}

	public Date getAssessmentCompletion() {
		return assessmentCompletion;
	}

	public void setAssessmentCompletion(Date assessmentCompletion) {
		this.assessmentCompletion = assessmentCompletion;
	}

	public Date getCommittedSbaCompletionDate() {
		return committedSbaCompletionDate;
	}

	public void setCommittedSbaCompletionDate(Date committedSbaCompletionDate) {
		this.committedSbaCompletionDate = committedSbaCompletionDate;
	}

	public String getDeploymentPlanUpdate() {
		return deploymentPlanUpdate;
	}

	public void setDeploymentPlanUpdate(String deploymentPlanUpdate) {
		this.deploymentPlanUpdate = deploymentPlanUpdate;
	}

	public long getDeploymentConfirmationPocId() {
		return deploymentConfirmationPocId;
	}

	public void setDeploymentConfirmationPocId(long deploymentConfirmationPocId) {
		this.deploymentConfirmationPocId = deploymentConfirmationPocId;
	}

	public String getDeploymentConfirmationPocName() {
		return deploymentConfirmationPocName;
	}

	public void setDeploymentConfirmationPocName(
			String deploymentConfirmationPocName) {
		this.deploymentConfirmationPocName = deploymentConfirmationPocName;
	}

	public String getDropReason() {
		return dropReason;
	}

	public void setDropReason(String dropReason) {
		this.dropReason = dropReason;
	}

	public String getAcademyPoc() {
		return academyPoc;
	}

	public void setAcademyPoc(String academyPoc) {
		this.academyPoc = academyPoc;
	}

	public Date getSbaAdministrationDate() {
		return sbaAdministrationDate;
	}

	public void setSbaAdministrationDate(Date sbaAdministrationDate) {
		this.sbaAdministrationDate = sbaAdministrationDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
