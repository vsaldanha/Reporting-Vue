package com.cts.trt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrtApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrtApplication.class, args);
	}
}
