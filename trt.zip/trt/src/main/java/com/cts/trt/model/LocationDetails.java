package com.cts.trt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "Location_Details")
public class LocationDetails implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private long locationId;
	
	@Column(name = "location_name")
	private String locationName;
	
	@Column(name = "offshore")
	private String offshore;

	public long getLocationId() {
		return locationId;
	}

	public void setLocationId(long locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getOffshore() {
		return offshore;
	}

	public void setOffshore(String offshore) {
		this.offshore = offshore;
	}

}
