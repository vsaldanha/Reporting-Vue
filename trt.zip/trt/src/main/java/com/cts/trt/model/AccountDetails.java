package com.cts.trt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "Account_Details")
public class AccountDetails implements Serializable {
 
	private static final long serialVersionUID = -3009157732242241604L;
	@Id
	private long account_id;
	
	@Column(name = "account_name")
	private String accountName;
 
	@Column(name = "parent_cust")
	private String parentCust;
	
	@Column(name = "portfolio_manager")
	private long portfolioManager;
	
	@ManyToOne
	@JoinColumn(name = "location_id")
	private LocationDetails location;

	public LocationDetails getLocation() {
		return location;
	}

	public void setLocation(LocationDetails location) {
		this.location = location;
	}

	public long getAccount_id() {
		return account_id;
	}

	public void setAccount_id(long account_id) {
		this.account_id = account_id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getParentCust() {
		return parentCust;
	}

	public void setParentCust(String parentCust) {
		this.parentCust = parentCust;
	}

	public long getPortfolioManager() {
		return portfolioManager;
	}

	public void setPortfolioManager(long portfolioManager) {
		this.portfolioManager = portfolioManager;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
