package com.rest.webservices.restWebService.controllers;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.rest.webservices.restWebService.beans.User;
import com.rest.webservices.restWebService.dao.UserDao;
import com.rest.webservices.restWebService.exceptions.UserNotFoundException;

@RestController
public class UserController {
	
	@Autowired
	private UserDao userDao;
	
	@GetMapping(path="/users")
	public List<User> retrieveAllUsers(){
		return userDao.findAll();
	}
	
	@GetMapping(path="/users/{id}")
	public User retrieveOneUsers(@PathVariable(value="id") Integer id){
		User findOne = userDao.findOne(id);
		if(findOne==null){
			throw new UserNotFoundException("id-"+id);
		}
		return findOne;
	}
	
	@PostMapping(path="/users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user){
		User savedUser=userDao.save(user);
		
		URI location=ServletUriComponentsBuilder
		.fromCurrentRequest()
		.path("/{id}")
		.buildAndExpand(savedUser.getId())
		.toUri();
		
		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping(path="/users/{id}")
	public void deleteUser(@PathVariable(value="id") Integer id){
		User deletedUser = userDao.deleteById(id);
		if(deletedUser==null){
			throw new UserNotFoundException("id-"+id);
		}
		
	}
	
}
